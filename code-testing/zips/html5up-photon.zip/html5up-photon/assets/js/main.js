/*
	Photon by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
*/

(function($) {

	skel.breakpoints({
		xlarge: '(max-width: 1680px)',
		large: '(max-width: 1140px)',
		medium: '(max-width: 980px)',
		small: '(max-width: 736px)',
		xsmall: '(max-width: 480px)',
		xxsmall: '(max-width: 320px)'
	});

	$(function() {

		var	$window = $(window),
			$body = $('body');


		

		// Disable animations/transitions until the page has loaded.
			$body.addClass('is-loading');

			$window.on('load', function() {
				window.setTimeout(function() {
					$body.removeClass('is-loading');
				}, 250);
			});

		// Fix: Placeholder polyfill.
			$('form').placeholder();

		// Prioritize "important" elements on mobile.
			skel.on('+mobile -mobile', function() {
				$.prioritize(
					'.important\\28 mobile\\29',
					skel.breakpoint('mobile').active
				);
			});

		// Scrolly.
			//$('.scrolly').scrolly();
			

	});

})(jQuery);

//document.getElementById("weas").href = "";
//document.getElementById("weas").classList.remove("scrolly");
var scroll=false;

// Start when button is clicked
$("#start_button").click(function(){
    /*$("#start_button").empty();
		let startbutton = $("<li><a href=''#one' class='button scrolly'>Recording</a></li>");
		$("#start_button").append(startbutton);
		$("#start_button").addClass('recording');
		$("#searchsubtitle").empty();*/

	if(!scroll){
	document.getElementById("weas").href = "#one";
	document.getElementById("weas").classList.add("scrolly");
	$('.scrolly').scrolly();

}
else{
document.getElementById("weas").href = "";
	document.getElementById("weas").classList.remove("scrolly");
$('.scrolly').scrolly();
}
scroll=!scroll;

	

		//render();
});


title = "Here goes the title"
abstract = "Here goes the abstract."
journalLink = "www.google.nl"

// $().(()){
// 	let article = $("
// 		<div class='row 150%'>
// 			<div class='4u 12u$(medium)'>
// 				<h3>"+title+"</h3>
// 				<p>"+abstract+"</p>
// 				<ul class='actions'>
// 					<li><a href="+journalLink+" class="button">Full article</a></li>
// 				</ul>
// 			</div>"
// 	);
// 	$("#articleposts").append(article);
// });
